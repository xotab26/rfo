#include "Database.h"


std::string CDatabase::Name;
std::string CDatabase::Host;
std::string CDatabase::User;
std::string CDatabase::Pass;